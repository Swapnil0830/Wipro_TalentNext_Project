// 1 c

public class Ladies extends Compartment {

	@Override
	public String notice() {
		// TODO Auto-generated method stub
		return new String("Ladies");
	}

}
