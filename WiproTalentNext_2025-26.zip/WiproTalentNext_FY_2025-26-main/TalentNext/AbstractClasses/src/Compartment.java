// 1 a

public abstract class Compartment {

	public abstract String notice();

}
