// function to find unique number in the given array of duplicates.
function find_unique(arr){

}