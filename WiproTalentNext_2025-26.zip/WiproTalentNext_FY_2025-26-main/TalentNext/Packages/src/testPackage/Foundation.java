// 1 a

package testPackage;

public class Foundation {

	// private
	private int var1;

	// default
	int var2;

	// public
	public int var3;

	// protected
	protected int var4;

}
