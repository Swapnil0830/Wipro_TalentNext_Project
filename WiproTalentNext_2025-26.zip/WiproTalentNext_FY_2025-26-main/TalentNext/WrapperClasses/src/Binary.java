// 3

public class Binary {

	public static void main(String[] args) {
		
		int x = 10;
		
		System.out.println(String.format("%08d", Integer.parseInt(Integer.toBinaryString(x))));
	}
	
}
